#ifndef CAT_GUARDIAN_EVIDENCE_SINK_H
#define CAT_GUARDIAN_EVIDENCE_SINK_H

#include "deterrent_request.h"

struct evidence_sink {
    void *context;
    int (*record_deterrent_request)(
        void *context,
        const struct deterrent_request *request
    );
};

#endif
